"""
main.py
CLI entry point — ties together storage, transaction_manager, and
analytics into a menu-driven console application.

TODO (you implement):
- On startup: load existing transactions from storage.py into a
  TransactionManager.
- Build a menu loop (similar to the Java/Python menu patterns you've
  already used in earlier assignments) offering:
    1. Add transaction
    2. View all transactions
    3. Search transactions
    4. Edit transaction
    5. Delete transaction
    6. View analytics (totals, category breakdown, monthly summary)
    7. Save & Exit
- After add/edit/delete, call storage.save_transactions(...) so changes
  persist to disk (or save once on exit — your choice, but document
  which you picked and why in your report).
- Wrap all input() calls that need a specific type/format in
  try/except so bad input doesn't crash the whole program.

This file is intentionally left mostly blank — wiring the modules
together into a working CLI is the core implementation task.
"""

DATA_FILE = "transactions.json"


def main():
    # TODO: implement the menu loop described above
    pass


if __name__ == "__main__":
    main()
