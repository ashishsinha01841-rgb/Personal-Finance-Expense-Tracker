"""
validators.py
Input validation functions — used by transaction_manager.py and main.py
before accepting user input. This is where you demonstrate the
"error handling" and "reliability" non-functional requirements.

TODO (you implement):
- is_valid_date(date_str): check format is YYYY-MM-DD and is a real date.
  Hint: look into Python's `datetime.datetime.strptime`.
- is_valid_amount(value): check it can be converted to a positive float.
- is_valid_type(ttype): check it is exactly "income" or "expense".
- is_valid_category(category): check it's a non-empty string.
"""

from datetime import datetime


def is_valid_date(date_str):
    # TODO
    pass


def is_valid_amount(value):
    # TODO
    pass


def is_valid_type(ttype):
    # TODO
    pass


def is_valid_category(category):
    # TODO
    pass
