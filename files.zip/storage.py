"""
storage.py
Handles reading and writing transactions to a JSON file.

TODO (you implement):
- load_transactions(filepath): read the JSON file, return a list of
  Transaction objects. Handle the case where the file doesn't exist yet
  (return an empty list instead of crashing — this is your "reliability"
  non-functional requirement in action).
- save_transactions(filepath, transactions): write the list of
  Transaction objects back to the JSON file.

Hints:
- Use the `json` module (json.load, json.dump).
- Use Transaction.to_dict() / Transaction.from_dict() from models.py to
  convert between Transaction objects and plain dictionaries.
- Wrap file operations in try/except to handle missing files or
  corrupted JSON gracefully.
"""

import json
from models import Transaction


def load_transactions(filepath):
    # TODO
    pass


def save_transactions(filepath, transactions):
    # TODO
    pass
