"""
models.py
Defines the Transaction data model.

TODO (you implement):
- Add any additional fields you think are useful (e.g., a unique ID).
- Implement to_dict() and from_dict() so a Transaction can be saved to
  and loaded from JSON via storage.py.
"""


class Transaction:
    def __init__(self, date, category, amount, ttype, note=""):
        """
        date: string, e.g. "2026-09-18"
        category: e.g. "Food", "Rent", "Salary"
        amount: positive float
        ttype: "income" or "expense"
        note: optional description
        """
        # TODO: store the parameters as instance attributes
        pass

    def to_dict(self):
        """Return this transaction as a dictionary (for saving to JSON)."""
        # TODO
        pass

    @staticmethod
    def from_dict(data):
        """Build a Transaction object from a dictionary (loaded from JSON)."""
        # TODO
        pass

    def __str__(self):
        """Return a human-readable representation for printing in the CLI."""
        # TODO: something like:
        # "[2026-09-18] Food - expense - 250.0 (lunch)"
        pass
