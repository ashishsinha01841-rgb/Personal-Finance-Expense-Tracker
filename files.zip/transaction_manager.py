"""
transaction_manager.py
Core CRUD logic for managing the in-memory list of transactions.
This class works on a list of Transaction objects; main.py will handle
all user I/O (input()/print()) and call into this class.

TODO (you implement):
- add_transaction(...): validate inputs (use validators.py), create a
  Transaction, append it to self.transactions.
- list_transactions(): return all transactions (optionally filtered by
  category or type — up to you how far you extend this).
- delete_transaction(index): remove a transaction by its position/id.
- edit_transaction(index, **updates): update one or more fields of an
  existing transaction.
- search_transactions(keyword): return transactions whose category or
  note contains the keyword (case-insensitive).
"""

from models import Transaction
import validators


class TransactionManager:
    def __init__(self):
        self.transactions = []

    def add_transaction(self, date, category, amount, ttype, note=""):
        # TODO: validate each field using validators.py.
        # If invalid, raise a ValueError with a clear message (main.py
        # will catch it and show the user a friendly error).
        pass

    def list_transactions(self):
        # TODO
        pass

    def delete_transaction(self, index):
        # TODO
        pass

    def edit_transaction(self, index, **updates):
        # TODO
        pass

    def search_transactions(self, keyword):
        # TODO
        pass
