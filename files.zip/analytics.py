"""
analytics.py
Reporting/analytics functions over a list of Transaction objects.
This is your third functional module (Reporting/Analytics).

TODO (you implement):
- total_income(transactions): sum of all "income" transactions.
- total_expense(transactions): sum of all "expense" transactions.
- net_balance(transactions): income - expense.
- category_breakdown(transactions): dict mapping category -> total
  amount spent/earned in that category.
- monthly_summary(transactions, year_month): total income/expense for
  a given "YYYY-MM" string.
- top_expense_category(transactions): the category with the highest
  total expense.
"""


def total_income(transactions):
    # TODO
    pass


def total_expense(transactions):
    # TODO
    pass


def net_balance(transactions):
    # TODO
    pass


def category_breakdown(transactions):
    # TODO
    pass


def monthly_summary(transactions, year_month):
    # TODO
    pass


def top_expense_category(transactions):
    # TODO
    pass
